
(function() {
  var noteForm = document.getElementById('note-form');
  var noteTitleInput = document.getElementById('note-title');
  var noteContentInput = document.getElementById('note-content');
  var noteList = document.getElementById('note-list');

  var timerMinutesInput = document.getElementById('timer-minutes');
  var timerStartBtn = document.getElementById('timer-start');
  var timerStopBtn = document.getElementById('timer-stop');
  var timerDisplay = document.getElementById('timer-display');
  var timerMinusBtn = document.getElementById('timer-minus');
  var timerPlusBtn = document.getElementById('timer-plus');
  var presetButtons = Array.prototype.slice.call(document.querySelectorAll('[data-preset]'));

  var notes = [];
  var countdownInterval = null;
  var expanded = Object.create(null);

  function sortedNotes() {
    return notes.slice().sort(function(a, b) {
      if (a.pinned === b.pinned) return b.createdAt - a.createdAt;
      return a.pinned ? -1 : 1;
    });
  }

  function isLong(text) {
    if (!text) return false;
    return text.length > 220 || (text.split('
').length >= 6);
  }

  function renderNotes() {
    noteList.innerHTML = '';

    sortedNotes().forEach(function(note) {
      var li = document.createElement('li');
      li.className = 'note-item';

      var header = document.createElement('div');
      header.className = 'note-header';

      var titleSpan = document.createElement('span');
      titleSpan.className = 'note-title';
      titleSpan.textContent = note.title || '(Sans titre)';

      var actions = document.createElement('div');
      actions.className = 'note-actions';

      var pinBtn = document.createElement('button');
      pinBtn.className = 'btn-icon';
      pinBtn.title = note.pinned ? 'Désépingler' : 'Épingler';
      pinBtn.textContent = note.pinned ? '★' : '☆';
      pinBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        note.pinned = !note.pinned;
        saveNotes();
      });

      var deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn-icon';
      deleteBtn.title = 'Supprimer';
      deleteBtn.textContent = '🗑';
      deleteBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        notes = notes.filter(function(n) { return n.id !== note.id; });
        delete expanded[note.id];
        saveNotes();
      });

      actions.appendChild(pinBtn);
      actions.appendChild(deleteBtn);

      header.appendChild(titleSpan);
      header.appendChild(actions);

      var contentDiv = document.createElement('div');
      contentDiv.className = 'note-content';
      contentDiv.textContent = note.content;

      var shouldCollapse = isLong(note.content) && !expanded[note.id];
      if (shouldCollapse) contentDiv.classList.add('collapsed');

      contentDiv.addEventListener('click', function() {
        if (!isLong(note.content)) return;
        expanded[note.id] = !expanded[note.id];
        renderNotes();
      });

      li.appendChild(header);
      li.appendChild(contentDiv);

      noteList.appendChild(li);
    });
  }

  function saveNotes() {
    chrome.storage.local.set({ notes: notes }, function() {
      if (chrome.runtime && chrome.runtime.lastError) {
        console.error('storage.set error', chrome.runtime.lastError);
      }
      renderNotes();
    });
  }

  function loadNotesAndTimer() {
    chrome.storage.local.get(['notes', 'timerEndAt'], function(data) {
      if (chrome.runtime && chrome.runtime.lastError) {
        console.error('storage.get error', chrome.runtime.lastError);
      }
      notes = Array.isArray(data.notes) ? data.notes : [];
      renderNotes();
      if (typeof data.timerEndAt === 'number') {
        startCountdown(data.timerEndAt);
      }
    });
  }

  noteForm.addEventListener('submit', function(e) {
    e.preventDefault();
    var title = (noteTitleInput.value || '').trim();
    var content = (noteContentInput.value || '').trim();
    if (!content) return;

    notes.push({
      id: Date.now(),
      title: title,
      content: content,
      pinned: false,
      createdAt: Date.now()
    });

    noteTitleInput.value = '';
    noteContentInput.value = '';
    saveNotes();
  });

  function clampMinutes(x) {
    var v = Number(x);
    if (!isFinite(v)) return 10;
    v = Math.round(v);
    if (v < 1) v = 1;
    if (v > 180) v = 180;
    return v;
  }

  function setMinutes(v) {
    timerMinutesInput.value = String(clampMinutes(v));
  }

  timerMinusBtn.addEventListener('click', function() {
    setMinutes(clampMinutes(timerMinutesInput.value) - 1);
  });

  timerPlusBtn.addEventListener('click', function() {
    setMinutes(clampMinutes(timerMinutesInput.value) + 1);
  });

  presetButtons.forEach(function(btn) {
    btn.addEventListener('click', function() {
      var v = Number(btn.getAttribute('data-preset'));
      setMinutes(v);
    });
  });

  function formatRemaining(ms) {
    if (ms <= 0) return 'Terminé';
    var totalSeconds = Math.floor(ms / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    var mm = String(minutes).padStart(2, '0');
    var ss = String(seconds).padStart(2, '0');
    return mm + ':' + ss;
  }

  function startCountdown(endAt) {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }

    function tick() {
      var remaining = endAt - Date.now();
      if (remaining <= 0) {
        timerDisplay.textContent = 'Terminé';
        clearInterval(countdownInterval);
        countdownInterval = null;
        chrome.storage.local.remove('timerEndAt');
        return;
      }
      timerDisplay.textContent = formatRemaining(remaining);
    }

    tick();
    countdownInterval = setInterval(tick, 1000);
  }

  timerStartBtn.addEventListener('click', function() {
    var minutes = clampMinutes(timerMinutesInput.value);
    var endAt = Date.now() + minutes * 60 * 1000;

    chrome.storage.local.set({ timerEndAt: endAt }, function() {
      startCountdown(endAt);
      chrome.runtime.sendMessage({ type: 'createTimer', minutes: minutes });
    });
  });

  timerStopBtn.addEventListener('click', function() {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }
    timerDisplay.textContent = 'Inactif';
    chrome.storage.local.remove('timerEndAt');
    chrome.runtime.sendMessage({ type: 'clearTimer' });
  });
  function init() {
    loadNotesAndTimer();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
