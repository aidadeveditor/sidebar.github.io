
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'createTimer') {
    const minutes = Number(message.minutes) || 0;
    if (minutes > 0) {
      chrome.alarms.clear('sidebar-notes-timer', () => {
        chrome.alarms.create('sidebar-notes-timer', { delayInMinutes: minutes });
      });
    }
  }
  if (message.type === 'clearTimer') {
    chrome.alarms.clear('sidebar-notes-timer');
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'sidebar-notes-timer') {
    chrome.notifications.create('', {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Minuterie terminée',
      message: 'Votre session de focus est terminée.'
    });
  }
});
