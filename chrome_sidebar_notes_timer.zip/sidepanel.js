
const noteForm = document.querySelector('.note-form');
const noteTitleInput = document.getElementById('note-title');
const noteContentInput = document.getElementById('note-content');
const noteList = document.getElementById('note-list');

const timerMinutesInput = document.getElementById('timer-minutes');
const timerStartBtn = document.getElementById('timer-start');
const timerStopBtn = document.getElementById('timer-stop');
const timerDisplay = document.getElementById('timer-display');

let notes = [];
let countdownInterval = null;

function renderNotes() {
  noteList.innerHTML = '';
  const sorted = [...notes].sort((a, b) => {
    if (a.pinned === b.pinned) {
      return b.createdAt - a.createdAt;
    }
    return a.pinned ? -1 : 1;
  });

  for (const note of sorted) {
    const li = document.createElement('li');
    li.className = 'note-item';

    const header = document.createElement('div');
    header.className = 'note-header';

    const titleSpan = document.createElement('span');
    titleSpan.className = 'note-title';
    titleSpan.textContent = note.title || '(Sans titre)';

    const actions = document.createElement('div');
    actions.className = 'note-actions';

    const pinBtn = document.createElement('button');
    pinBtn.className = 'btn-icon';
    pinBtn.title = note.pinned ? 'Désépingler' : 'Épingler';
    pinBtn.textContent = note.pinned ? '★' : '☆';
    pinBtn.addEventListener('click', () => {
      note.pinned = !note.pinned;
      saveNotes();
    });

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-icon';
    deleteBtn.title = 'Supprimer';
    deleteBtn.textContent = '🗑';
    deleteBtn.addEventListener('click', () => {
      notes = notes.filter(n => n.id !== note.id);
      saveNotes();
    });

    actions.appendChild(pinBtn);
    actions.appendChild(deleteBtn);

    header.appendChild(titleSpan);
    header.appendChild(actions);

    const contentDiv = document.createElement('div');
    contentDiv.className = 'note-content';
    contentDiv.textContent = note.content;

    li.appendChild(header);
    li.appendChild(contentDiv);

    noteList.appendChild(li);
  }
}

function saveNotes() {
  chrome.storage.local.set({ notes }, () => {
    renderNotes();
  });
}

function loadNotes() {
  chrome.storage.local.get(['notes', 'timerEndAt'], data => {
    notes = Array.isArray(data.notes) ? data.notes : [];
    renderNotes();
    if (data.timerEndAt) {
      startCountdown(data.timerEndAt);
    }
  });
}

noteForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = noteTitleInput.value.trim();
  const content = noteContentInput.value.trim();
  if (!content) return;

  const newNote = {
    id: Date.now(),
    title,
    content,
    pinned: false,
    createdAt: Date.now()
  };
  notes.push(newNote);
  noteTitleInput.value = '';
  noteContentInput.value = '';
  saveNotes();
});

function formatRemaining(ms) {
  if (ms <= 0) return 'Terminé';
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function startCountdown(endTimestamp) {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }
  function update() {
    const now = Date.now();
    const remaining = endTimestamp - now;
    if (remaining <= 0) {
      timerDisplay.textContent = 'Terminé';
      clearInterval(countdownInterval);
      countdownInterval = null;
      chrome.storage.local.remove('timerEndAt');
      return;
    }
    timerDisplay.textContent = formatRemaining(remaining);
  }
  update();
  countdownInterval = setInterval(update, 1000);
}

timerStartBtn.addEventListener('click', () => {
  const minutes = parseInt(timerMinutesInput.value, 10);
  if (isNaN(minutes) || minutes <= 0) return;
  const endAt = Date.now() + minutes * 60 * 1000;
  chrome.storage.local.set({ timerEndAt: endAt }, () => {
    startCountdown(endAt);
    chrome.runtime.sendMessage({ type: 'createTimer', minutes });
  });
});

timerStopBtn.addEventListener('click', () => {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }
  timerDisplay.textContent = 'Inactif';
  chrome.storage.local.remove('timerEndAt');
  chrome.runtime.sendMessage({ type: 'clearTimer' });
});

document.addEventListener('DOMContentLoaded', loadNotes);
