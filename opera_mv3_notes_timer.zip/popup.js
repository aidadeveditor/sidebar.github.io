
const noteForm = document.getElementById('note-form');
const noteTitleInput = document.getElementById('note-title');
const noteContentInput = document.getElementById('note-content');
const noteList = document.getElementById('note-list');

const timerMinutesInput = document.getElementById('timer-minutes');
const timerStartBtn = document.getElementById('timer-start');
const timerPauseBtn = document.getElementById('timer-pause');
const timerStopBtn = document.getElementById('timer-stop');
const timerDisplay = document.getElementById('timer-display');
const timerMinusBtn = document.getElementById('timer-minus');
const timerPlusBtn = document.getElementById('timer-plus');
const presetButtons = Array.from(document.querySelectorAll('[data-preset]'));

let notes = [];
let countdownInterval = null;
const expanded = Object.create(null);

function sortedNotes() {
  return [...notes].sort((a, b) => {
    if (a.pinned === b.pinned) return b.createdAt - a.createdAt;
    return a.pinned ? -1 : 1;
  });
}

function isLong(text) {
  if (!text) return false;
  return text.length > 220 || text.split('
').length >= 6;
}

function renderNotes() {
  noteList.innerHTML = '';
  for (const note of sortedNotes()) {
    const li = document.createElement('li');
    li.className = 'note-item';

    const header = document.createElement('div');
    header.className = 'note-header';

    const titleSpan = document.createElement('span');
    titleSpan.className = 'note-title';
    titleSpan.textContent = note.title || '(Sans titre)';

    const actions = document.createElement('div');
    actions.className = 'note-actions';

    const pinBtn = document.createElement('button');
    pinBtn.className = 'btn-icon';
    pinBtn.title = note.pinned ? 'Désépingler' : 'Épingler';
    pinBtn.textContent = note.pinned ? '★' : '☆';
    pinBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      note.pinned = !note.pinned;
      saveNotes();
    });

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-icon';
    deleteBtn.title = 'Supprimer';
    deleteBtn.textContent = '🗑';
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      notes = notes.filter(n => n.id !== note.id);
      delete expanded[note.id];
      saveNotes();
    });

    actions.appendChild(pinBtn);
    actions.appendChild(deleteBtn);

    header.appendChild(titleSpan);
    header.appendChild(actions);

    const contentDiv = document.createElement('div');
    contentDiv.className = 'note-content';
    contentDiv.textContent = note.content;

    const shouldCollapse = isLong(note.content) && !expanded[note.id];
    if (shouldCollapse) contentDiv.classList.add('collapsed');

    contentDiv.addEventListener('click', () => {
      if (!isLong(note.content)) return;
      expanded[note.id] = !expanded[note.id];
      renderNotes();
    });

    li.appendChild(header);
    li.appendChild(contentDiv);
    noteList.appendChild(li);
  }
}

function saveNotes() {
  chrome.storage.local.set({ notes }, () => renderNotes());
}

function clampMinutes(x) {
  let v = Number(x);
  if (!Number.isFinite(v)) v = 10;
  v = Math.round(v);
  if (v < 1) v = 1;
  if (v > 180) v = 180;
  return v;
}

function setMinutes(v) {
  timerMinutesInput.value = String(clampMinutes(v));
}

timerMinusBtn.addEventListener('click', () => setMinutes(clampMinutes(timerMinutesInput.value) - 1));
timerPlusBtn.addEventListener('click', () => setMinutes(clampMinutes(timerMinutesInput.value) + 1));
for (const btn of presetButtons) {
  btn.addEventListener('click', () => setMinutes(Number(btn.getAttribute('data-preset'))));
}

function setDisplay(text) {
  timerDisplay.textContent = text;
}

function formatRemaining(ms) {
  if (ms <= 0) return 'Terminé';
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function stopCountdown() {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }
}

function startCountdown(endAt) {
  stopCountdown();
  const tick = () => {
    const remaining = endAt - Date.now();
    if (remaining <= 0) {
      setDisplay('Terminé');
      stopCountdown();
      chrome.storage.local.remove(['timerEndAt', 'timerPausedRemaining']);
      return;
    }
    setDisplay(formatRemaining(remaining));
  };
  tick();
  countdownInterval = setInterval(tick, 250);
}

noteForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = noteTitleInput.value.trim();
  const content = noteContentInput.value.trim();
  if (!content) return;
  notes.push({ id: Date.now(), title, content, pinned: false, createdAt: Date.now() });
  noteTitleInput.value = '';
  noteContentInput.value = '';
  saveNotes();
});

timerStartBtn.addEventListener('click', async () => {
  const data = await chrome.storage.local.get(['timerPausedRemaining']);
  const paused = (typeof data.timerPausedRemaining === 'number') ? data.timerPausedRemaining : 0;

  if (paused > 0) {
    const endAt = Date.now() + paused;
    await chrome.storage.local.set({ timerEndAt: endAt });
    await chrome.storage.local.remove('timerPausedRemaining');
    startCountdown(endAt);
    chrome.runtime.sendMessage({ type: 'startTimer', delayMs: paused });
    return;
  }

  const minutes = clampMinutes(timerMinutesInput.value);
  const endAt2 = Date.now() + minutes * 60 * 1000;
  await chrome.storage.local.set({ timerEndAt: endAt2 });
  await chrome.storage.local.remove('timerPausedRemaining');
  startCountdown(endAt2);
  chrome.runtime.sendMessage({ type: 'startTimer', delayMs: minutes * 60 * 1000 });
});

timerPauseBtn.addEventListener('click', async () => {
  const data = await chrome.storage.local.get(['timerEndAt', 'timerPausedRemaining']);

  if (typeof data.timerPausedRemaining === 'number' && data.timerPausedRemaining > 0) {
    const endAt = Date.now() + data.timerPausedRemaining;
    await chrome.storage.local.set({ timerEndAt: endAt });
    await chrome.storage.local.remove('timerPausedRemaining');
    startCountdown(endAt);
    chrome.runtime.sendMessage({ type: 'startTimer', delayMs: data.timerPausedRemaining });
    return;
  }

  if (typeof data.timerEndAt !== 'number') return;
  let remaining = data.timerEndAt - Date.now();
  if (remaining < 0) remaining = 0;

  await chrome.storage.local.set({ timerPausedRemaining: remaining });
  await chrome.storage.local.remove('timerEndAt');
  stopCountdown();
  setDisplay('Pause');
  chrome.runtime.sendMessage({ type: 'stopTimer' });
});

timerStopBtn.addEventListener('click', async () => {
  stopCountdown();
  setDisplay('Inactif');
  await chrome.storage.local.remove(['timerEndAt', 'timerPausedRemaining']);
  chrome.runtime.sendMessage({ type: 'stopTimer' });
});

async function loadAll() {
  const data = await chrome.storage.local.get(['notes', 'timerEndAt', 'timerPausedRemaining']);
  notes = Array.isArray(data.notes) ? data.notes : [];
  renderNotes();

  if (typeof data.timerPausedRemaining === 'number' && data.timerPausedRemaining > 0) {
    setDisplay('Pause');
    return;
  }

  if (typeof data.timerEndAt === 'number') {
    startCountdown(data.timerEndAt);
  } else {
    setDisplay('Inactif');
  }
}

loadAll();
