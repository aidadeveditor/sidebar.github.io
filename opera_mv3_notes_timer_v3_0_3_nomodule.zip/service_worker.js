
const ALARM_NAME = 'notes-timer-alarm';

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'startTimer') {
    const delayMs = Number(msg.delayMs) || 0;
    chrome.alarms.clear(ALARM_NAME, () => {
      if (delayMs > 0) {
        chrome.alarms.create(ALARM_NAME, { delayInMinutes: delayMs / 60000 });
      }
    });
  }

  if (msg.type === 'stopTimer') {
    chrome.alarms.clear(ALARM_NAME);
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm || alarm.name !== ALARM_NAME) return;
  chrome.notifications.create('', {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: 'Minuterie terminée',
    message: 'Votre session est terminée.'
  });
});
