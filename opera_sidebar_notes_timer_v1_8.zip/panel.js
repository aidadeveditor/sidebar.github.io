
(function() {
  var noteForm = document.getElementById('note-form');
  var noteTitleInput = document.getElementById('note-title');
  var noteContentInput = document.getElementById('note-content');
  var noteList = document.getElementById('note-list');

  var timerMinutesInput = document.getElementById('timer-minutes');
  var timerStartBtn = document.getElementById('timer-start');
  var timerPauseBtn = document.getElementById('timer-pause');
  var timerStopBtn = document.getElementById('timer-stop');
  var timerDisplay = document.getElementById('timer-display');
  var timerMinusBtn = document.getElementById('timer-minus');
  var timerPlusBtn = document.getElementById('timer-plus');
  var presetButtons = Array.prototype.slice.call(document.querySelectorAll('[data-preset]'));

  var notes = [];
  var countdownInterval = null;
  var expanded = Object.create(null);

  function bindIf(el, event, handler) {
    if (!el) return;
    el.addEventListener(event, handler);
  }

  function sortedNotes() {
    return notes.slice().sort(function(a, b) {
      if (a.pinned === b.pinned) return b.createdAt - a.createdAt;
      return a.pinned ? -1 : 1;
    });
  }

  function isLong(text) {
    if (!text) return false;
    return text.length > 220 || (text.split('
').length >= 6);
  }

  function renderNotes() {
    noteList.innerHTML = '';

    sortedNotes().forEach(function(note) {
      var li = document.createElement('li');
      li.className = 'note-item';

      var header = document.createElement('div');
      header.className = 'note-header';

      var titleSpan = document.createElement('span');
      titleSpan.className = 'note-title';
      titleSpan.textContent = note.title || '(Sans titre)';

      var actions = document.createElement('div');
      actions.className = 'note-actions';

      var pinBtn = document.createElement('button');
      pinBtn.className = 'btn-icon';
      pinBtn.title = note.pinned ? 'Désépingler' : 'Épingler';
      pinBtn.textContent = note.pinned ? '★' : '☆';
      pinBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        note.pinned = !note.pinned;
        saveNotes();
      });

      var deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn-icon';
      deleteBtn.title = 'Supprimer';
      deleteBtn.textContent = '🗑';
      deleteBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        notes = notes.filter(function(n) { return n.id !== note.id; });
        delete expanded[note.id];
        saveNotes();
      });

      actions.appendChild(pinBtn);
      actions.appendChild(deleteBtn);

      header.appendChild(titleSpan);
      header.appendChild(actions);

      var contentDiv = document.createElement('div');
      contentDiv.className = 'note-content';
      contentDiv.textContent = note.content;

      var shouldCollapse = isLong(note.content) && !expanded[note.id];
      if (shouldCollapse) contentDiv.classList.add('collapsed');

      contentDiv.addEventListener('click', function() {
        if (!isLong(note.content)) return;
        expanded[note.id] = !expanded[note.id];
        renderNotes();
      });

      li.appendChild(header);
      li.appendChild(contentDiv);
      noteList.appendChild(li);
    });
  }

  function saveNotes() {
    chrome.storage.local.set({ notes: notes }, function() {
      renderNotes();
    });
  }

  function clampMinutes(x) {
    var v = Number(x);
    if (!isFinite(v)) return 10;
    v = Math.round(v);
    if (v < 1) v = 1;
    if (v > 180) v = 180;
    return v;
  }

  function setMinutes(v) {
    timerMinutesInput.value = String(clampMinutes(v));
  }

  function setDisplay(text) {
    timerDisplay.textContent = text;
  }

  function formatRemaining(ms) {
    if (ms <= 0) return 'Terminé';
    var totalSeconds = Math.floor(ms / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    return String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
  }

  function startCountdown(endAt) {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }

    function tick() {
      var remaining = endAt - Date.now();
      if (remaining <= 0) {
        setDisplay('Terminé');
        clearInterval(countdownInterval);
        countdownInterval = null;
        chrome.storage.local.remove(['timerEndAt', 'timerPausedRemaining']);
        return;
      }
      setDisplay(formatRemaining(remaining));
    }

    tick();
    countdownInterval = setInterval(tick, 250);
  }

  function stopCountdown() {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }
  }

  function loadAll() {
    chrome.storage.local.get(['notes', 'timerEndAt', 'timerPausedRemaining'], function(data) {
      notes = Array.isArray(data.notes) ? data.notes : [];
      renderNotes();

      if (typeof data.timerPausedRemaining === 'number' && data.timerPausedRemaining > 0) {
        stopCountdown();
        setDisplay('Pause');
        return;
      }

      if (typeof data.timerEndAt === 'number') {
        startCountdown(data.timerEndAt);
      } else {
        setDisplay('Inactif');
      }
    });
  }

  bindIf(noteForm, 'submit', function(e) {
    e.preventDefault();
    var title = (noteTitleInput.value || '').trim();
    var content = (noteContentInput.value || '').trim();
    if (!content) return;

    notes.push({
      id: Date.now(),
      title: title,
      content: content,
      pinned: false,
      createdAt: Date.now()
    });

    noteTitleInput.value = '';
    noteContentInput.value = '';
    saveNotes();
  });

  bindIf(timerMinusBtn, 'click', function() {
    setMinutes(clampMinutes(timerMinutesInput.value) - 1);
  });

  bindIf(timerPlusBtn, 'click', function() {
    setMinutes(clampMinutes(timerMinutesInput.value) + 1);
  });

  (presetButtons || []).forEach(function(btn) {
    btn.addEventListener('click', function() {
      setMinutes(Number(btn.getAttribute('data-preset')));
    });
  });

  bindIf(timerStartBtn, 'click', function() {
    chrome.storage.local.get(['timerPausedRemaining'], function(data) {
      var paused = (typeof data.timerPausedRemaining === 'number') ? data.timerPausedRemaining : 0;

      if (paused > 0) {
        var endAt = Date.now() + paused;
        chrome.storage.local.set({ timerEndAt: endAt }, function() {
          chrome.storage.local.remove('timerPausedRemaining', function() {
            startCountdown(endAt);
            chrome.runtime.sendMessage({ type: 'createTimerMs', delayMs: paused });
          });
        });
        return;
      }

      var minutes = clampMinutes(timerMinutesInput.value);
      var endAt2 = Date.now() + minutes * 60 * 1000;
      chrome.storage.local.set({ timerEndAt: endAt2 }, function() {
        chrome.storage.local.remove('timerPausedRemaining', function() {
          startCountdown(endAt2);
          chrome.runtime.sendMessage({ type: 'createTimer', minutes: minutes });
        });
      });
    });
  });

  bindIf(timerPauseBtn, 'click', function() {
    chrome.storage.local.get(['timerEndAt', 'timerPausedRemaining'], function(data) {
      if (typeof data.timerPausedRemaining === 'number' && data.timerPausedRemaining > 0) {
        var endAt = Date.now() + data.timerPausedRemaining;
        chrome.storage.local.set({ timerEndAt: endAt }, function() {
          chrome.storage.local.remove('timerPausedRemaining', function() {
            startCountdown(endAt);
            chrome.runtime.sendMessage({ type: 'createTimerMs', delayMs: data.timerPausedRemaining });
          });
        });
        return;
      }

      if (typeof data.timerEndAt !== 'number') return;
      var remaining = data.timerEndAt - Date.now();
      if (remaining < 0) remaining = 0;

      chrome.storage.local.set({ timerPausedRemaining: remaining }, function() {
        chrome.storage.local.remove('timerEndAt', function() {
          stopCountdown();
          setDisplay('Pause');
          chrome.runtime.sendMessage({ type: 'clearTimer' });
        });
      });
    });
  });

  bindIf(timerStopBtn, 'click', function() {
    stopCountdown();
    setDisplay('Inactif');
    chrome.storage.local.remove(['timerEndAt', 'timerPausedRemaining']);
    chrome.runtime.sendMessage({ type: 'clearTimer' });
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadAll);
  } else {
    loadAll();
  }
})();
