
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message && message.type === 'createTimer') {
    var minutes = Number(message.minutes) || 0;
    if (minutes > 0) {
      chrome.alarms.clear('sidebar-notes-timer', function() {
        chrome.alarms.create('sidebar-notes-timer', { delayInMinutes: minutes });
      });
    }
  }

  if (message && message.type === 'createTimerMs') {
    var delayMs = Number(message.delayMs) || 0;
    if (delayMs > 0) {
      chrome.alarms.clear('sidebar-notes-timer', function() {
        chrome.alarms.create('sidebar-notes-timer', { delayInMinutes: delayMs / 60000 });
      });
    }
  }

  if (message && message.type === 'clearTimer') {
    chrome.alarms.clear('sidebar-notes-timer');
  }
});

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm && alarm.name === 'sidebar-notes-timer') {
    chrome.notifications.create('', {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Minuterie terminée',
      message: 'Votre session est terminée.'
    });
  }
});
