
var LS_NOTES = 'sidebar_notes_notes_v1';
var LS_TIMER_END = 'sidebar_notes_timerEndAt_v1';

function _safeParse(jsonText, fallback) {
  try { return JSON.parse(jsonText); } catch (e) { return fallback; }
}

function getNotes() {
  var raw = localStorage.getItem(LS_NOTES);
  var data = _safeParse(raw, []);
  if (!Array.isArray(data)) return [];
  return data;
}

function setNotes(notes) {
  if (!Array.isArray(notes)) notes = [];
  localStorage.setItem(LS_NOTES, JSON.stringify(notes));
}

function getTimerEndAt() {
  var raw = localStorage.getItem(LS_TIMER_END);
  if (!raw) return null;
  var n = Number(raw);
  if (!isFinite(n)) return null;
  return n;
}

function setTimerEndAt(endAt) {
  if (endAt === null || endAt === undefined) {
    localStorage.removeItem(LS_TIMER_END);
    return;
  }
  localStorage.setItem(LS_TIMER_END, String(Number(endAt)));
}

function setTimerMinutes(minutes) {
  minutes = Number(minutes) || 0;
  if (minutes <= 0) return null;
  var endAt = Date.now() + minutes * 60 * 1000;
  setTimerEndAt(endAt);

  chrome.alarms.clear('sidebar-notes-timer', function() {
    chrome.alarms.create('sidebar-notes-timer', { delayInMinutes: minutes });
  });

  return endAt;
}

function clearTimer() {
  chrome.alarms.clear('sidebar-notes-timer');
  setTimerEndAt(null);
}

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm && alarm.name === 'sidebar-notes-timer') {
    setTimerEndAt(null);
    chrome.notifications.create('', {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Minuterie terminée',
      message: 'Votre session est terminée.'
    });
  }
});
