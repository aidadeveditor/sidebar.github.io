
(function() {
  var noteForm = document.getElementById('note-form');
  var noteTitleInput = document.getElementById('note-title');
  var noteContentInput = document.getElementById('note-content');
  var noteList = document.getElementById('note-list');

  var timerMinutesInput = document.getElementById('timer-minutes');
  var timerStartBtn = document.getElementById('timer-start');
  var timerStopBtn = document.getElementById('timer-stop');
  var timerDisplay = document.getElementById('timer-display');
  var timerMinusBtn = document.getElementById('timer-minus');
  var timerPlusBtn = document.getElementById('timer-plus');
  var presetButtons = Array.prototype.slice.call(document.querySelectorAll('[data-preset]'));

  var bg = null;
  try {
    bg = chrome.extension.getBackgroundPage();
  } catch (e) {
    console.error('Cannot access background page', e);
  }

  var notes = [];
  var countdownInterval = null;
  var expanded = Object.create(null);

  function clampMinutes(x) {
    var v = Number(x);
    if (!isFinite(v)) return 10;
    v = Math.round(v);
    if (v < 1) v = 1;
    if (v > 180) v = 180;
    return v;
  }

  function setMinutes(v) {
    timerMinutesInput.value = String(clampMinutes(v));
  }

  function sortedNotes() {
    return notes.slice().sort(function(a, b) {
      if (a.pinned === b.pinned) return b.createdAt - a.createdAt;
      return a.pinned ? -1 : 1;
    });
  }

  function isLong(text) {
    if (!text) return false;
    return text.length > 220 || (text.split('
').length >= 6);
  }

  function renderNotes() {
    noteList.innerHTML = '';

    sortedNotes().forEach(function(note) {
      var li = document.createElement('li');
      li.className = 'note-item';

      var header = document.createElement('div');
      header.className = 'note-header';

      var titleSpan = document.createElement('span');
      titleSpan.className = 'note-title';
      titleSpan.textContent = note.title || '(Sans titre)';

      var actions = document.createElement('div');
      actions.className = 'note-actions';

      var pinBtn = document.createElement('button');
      pinBtn.className = 'btn-icon';
      pinBtn.title = note.pinned ? 'Désépingler' : 'Épingler';
      pinBtn.textContent = note.pinned ? '★' : '☆';
      pinBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        note.pinned = !note.pinned;
        saveNotes();
      });

      var deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn-icon';
      deleteBtn.title = 'Supprimer';
      deleteBtn.textContent = '🗑';
      deleteBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        notes = notes.filter(function(n) { return n.id !== note.id; });
        delete expanded[note.id];
        saveNotes();
      });

      actions.appendChild(pinBtn);
      actions.appendChild(deleteBtn);

      header.appendChild(titleSpan);
      header.appendChild(actions);

      var contentDiv = document.createElement('div');
      contentDiv.className = 'note-content';
      contentDiv.textContent = note.content;

      var shouldCollapse = isLong(note.content) && !expanded[note.id];
      if (shouldCollapse) contentDiv.classList.add('collapsed');

      contentDiv.addEventListener('click', function() {
        if (!isLong(note.content)) return;
        expanded[note.id] = !expanded[note.id];
        renderNotes();
      });

      li.appendChild(header);
      li.appendChild(contentDiv);
      noteList.appendChild(li);
    });
  }

  function saveNotes() {
    if (bg && typeof bg.setNotes === 'function') {
      bg.setNotes(notes);
    }
    renderNotes();
  }

  function loadNotesAndTimer() {
    if (bg && typeof bg.getNotes === 'function') {
      notes = bg.getNotes() || [];
    } else {
      notes = [];
    }
    renderNotes();

    if (bg && typeof bg.getTimerEndAt === 'function') {
      var endAt = bg.getTimerEndAt();
      if (typeof endAt === 'number') startCountdown(endAt);
    }
  }

  noteForm.addEventListener('submit', function(e) {
    e.preventDefault();
    var title = (noteTitleInput.value || '').trim();
    var content = (noteContentInput.value || '').trim();
    if (!content) return;

    notes.push({
      id: Date.now(),
      title: title,
      content: content,
      pinned: false,
      createdAt: Date.now()
    });

    noteTitleInput.value = '';
    noteContentInput.value = '';
    saveNotes();
  });

  timerMinusBtn.addEventListener('click', function() {
    setMinutes(clampMinutes(timerMinutesInput.value) - 1);
  });

  timerPlusBtn.addEventListener('click', function() {
    setMinutes(clampMinutes(timerMinutesInput.value) + 1);
  });

  presetButtons.forEach(function(btn) {
    btn.addEventListener('click', function() {
      var v = Number(btn.getAttribute('data-preset'));
      setMinutes(v);
    });
  });

  function formatRemaining(ms) {
    if (ms <= 0) return 'Terminé';
    var totalSeconds = Math.floor(ms / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    var mm = String(minutes).padStart(2, '0');
    var ss = String(seconds).padStart(2, '0');
    return mm + ':' + ss;
  }

  function startCountdown(endAt) {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }

    function tick() {
      var remaining = endAt - Date.now();
      if (remaining <= 0) {
        timerDisplay.textContent = 'Terminé';
        clearInterval(countdownInterval);
        countdownInterval = null;
        return;
      }
      timerDisplay.textContent = formatRemaining(remaining);
    }

    tick();
    countdownInterval = setInterval(tick, 1000);
  }

  timerStartBtn.addEventListener('click', function() {
    var minutes = clampMinutes(timerMinutesInput.value);
    if (bg && typeof bg.setTimerMinutes === 'function') {
      var endAt = bg.setTimerMinutes(minutes);
      if (typeof endAt === 'number') startCountdown(endAt);
    }
  });

  timerStopBtn.addEventListener('click', function() {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }
    timerDisplay.textContent = 'Inactif';
    if (bg && typeof bg.clearTimer === 'function') {
      bg.clearTimer();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadNotesAndTimer);
  } else {
    loadNotesAndTimer();
  }
})();
