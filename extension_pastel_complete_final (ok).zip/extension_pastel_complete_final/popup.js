
function showConfirm(msg, yesCallback) {
  if (confirm(msg)) yesCallback();
}

function showToast(msg) {
  const toast = document.createElement('div');
  toast.textContent = msg;
  toast.style.cssText = 'position:fixed;top:10px;right:10px;background:#4caf50;color:white;padding:12px 20px;border-radius:6px;z-index:10000;font-size:14px;box-shadow:0 4px 12px rgba(0,0,0,0.15);';
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}


(function(){
  window.addEventListener('error', function(e){
    try {
      var el=document.getElementById('js-status');
      if (el) el.textContent='JS: erreur (ouvre Inspect views)';
    } catch(_) {}
  });
  try {
    var el=document.getElementById('js-status');
    if (el) el.textContent='JS: chargé';
  } catch(_) {}
})();


const noteForm = document.getElementById('note-form');
const noteTitleInput = document.getElementById('note-title');
const noteContentInput = document.getElementById('note-content');
const noteList = document.getElementById('note-list');

const timerMinutesInput = document.getElementById('timer-minutes');
const timerStartBtn = document.getElementById('timer-start');
const timerPauseBtn = document.getElementById('timer-pause');
const timerStopBtn = document.getElementById('timer-stop');
const timerDisplay = document.getElementById('timer-display');
const timerMinusBtn = document.getElementById('timer-minus');
const timerPlusBtn = document.getElementById('timer-plus');
const presetButtons = Array.from(document.querySelectorAll('[data-preset]'));

let notes = [];
let countdownInterval = null;
const expanded = Object.create(null);

function sortedNotes() {
  return [...notes].sort((a, b) => {
    if (a.pinned === b.pinned) return b.createdAt - a.createdAt;
    return a.pinned ? -1 : 1;
  });
}

function isLong(text) {
  if (!text) return false;
  return text.length > 350 || text.split('\n').length >= 6;
}

function renderNotes() {
  noteList.innerHTML = '';
  for (const note of sortedNotes()) {
    const li = document.createElement('li');
    li.className = 'note-item';

    const header = document.createElement('div');
    header.className = 'note-header';

    const titleSpan = document.createElement('span');
    titleSpan.className = 'note-title';
    titleSpan.textContent = note.title || '(Sans titre)';

    const actions = document.createElement('div');
    actions.className = 'note-actions';

    const pinBtn = document.createElement('button');
    pinBtn.className = 'btn-icon';
    pinBtn.title = note.pinned ? 'Désépingler' : 'Épingler';
    pinBtn.textContent = note.pinned ? '★' : '☆';
    pinBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      note.pinned = !note.pinned;
      saveNotes();
    });

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-icon';
    deleteBtn.title = 'Supprimer';
    deleteBtn.textContent = '🗑';
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showConfirm('Supprimer "' + (note.title || '(Sans titre)') + '" ?', () => {
        notes = notes.filter(n => n.id !== note.id);
        delete expanded[note.id];
        saveNotes();
      });
    });

    actions.appendChild(pinBtn);
const copyBtn = document.createElement('button');
copyBtn.className = 'btn-icon';
copyBtn.title = 'Copier';
copyBtn.textContent = '📋';
copyBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  navigator.clipboard.writeText(note.content).then(() => {
            copyBtn.textContent = '✅';
            showToast('Note copiée !');
    copyBtn.textContent = '✅';
    copyBtn.style.color = '#4caf50';
    setTimeout(() => {
      copyBtn.textContent = '📋';
      copyBtn.style.color = '';
    }, 1500);
  }).catch(() => {
    console.error('Copy failed');
  });
});
actions.appendChild(copyBtn);
    actions.appendChild(deleteBtn);

    header.appendChild(titleSpan);
    header.appendChild(actions);

    const contentDiv = document.createElement('div');
    contentDiv.className = 'note-content';
    contentDiv.textContent = note.content;

    const shouldCollapse = isLong(note.content) && !expanded[note.id];
    if (shouldCollapse) contentDiv.classList.add('collapsed');

    contentDiv.addEventListener('click', () => {
      if (!isLong(note.content)) return;
      expanded[note.id] = !expanded[note.id];
      renderNotes();
    });

    li.appendChild(header);
    li.appendChild(contentDiv);
    noteList.appendChild(li);
  }
}

function saveNotes() {
  chrome.storage.local.set({ notes }, () => {
    if (chrome.runtime && chrome.runtime.lastError) {
      console.error('storage.set notes error', chrome.runtime.lastError);
    }
    renderNotes();
  });
}

function clampMinutes(x) {
  let v = Number(x);
  if (!Number.isFinite(v)) v = 10;
  v = Math.round(v);
  if (v < 1) v = 1;
  if (v > 180) v = 180;
  return v;
}

function setMinutes(v) {
  timerMinutesInput.value = String(clampMinutes(v));
}

timerMinusBtn.addEventListener('click', () => setMinutes(clampMinutes(timerMinutesInput.value) - 1));
timerPlusBtn.addEventListener('click', () => setMinutes(clampMinutes(timerMinutesInput.value) + 1));
for (const btn of presetButtons) {
  btn.addEventListener('click', () => setMinutes(Number(btn.getAttribute('data-preset'))));
}

function setDisplay(text) {

function setPauseDisplay(ms) {
  if (typeof ms === 'number' && ms > 0) {
    setDisplay('Pause ' + formatRemaining(ms));
  } else {
    setPauseDisplay(remaining);
  }
}

  timerDisplay.textContent = text;
}

function formatRemaining(ms) {
  if (ms <= 0) return 'Terminé';
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function stopCountdown() {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
  }
}

function startCountdown(endAt) {
  stopCountdown();
  const tick = () => {
    const remaining = endAt - Date.now();
    if (remaining <= 0) {
      setDisplay('Terminé');
      stopCountdown();
      chrome.storage.local.remove(['timerEndAt', 'timerPausedRemaining']);
      return;
    }
    setDisplay(formatRemaining(remaining));
  };
  tick();
  countdownInterval = setInterval(tick, 250);
}

function sendStartTimer(delayMs) {
  chrome.runtime.sendMessage({ type: 'startTimer', delayMs });
}

function sendStopTimer() {
  chrome.runtime.sendMessage({ type: 'stopTimer' });
}

noteForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = noteTitleInput.value.trim();
  const content = noteContentInput.value.trim();
  if (!content) return;
  notes.push({ id: Date.now(), title, content, pinned: false, createdAt: Date.now() });
  noteTitleInput.value = '';
  noteContentInput.value = '';
  saveNotes();
});

timerStartBtn.addEventListener('click', () => {
  chrome.storage.local.get(['timerPausedRemaining'], (data) => {
    if (chrome.runtime && chrome.runtime.lastError) {
      console.error('storage.get pause error', chrome.runtime.lastError);
    }

    const paused = (typeof data.timerPausedRemaining === 'number') ? data.timerPausedRemaining : 0;
    if (paused > 0) {
      const endAt = Date.now() + paused;
      chrome.storage.local.set({ timerEndAt: endAt }, () => {
        chrome.storage.local.remove('timerPausedRemaining', () => {
          startCountdown(endAt);
          sendStartTimer(paused);
        });
      });
      return;
    }

    const minutes = clampMinutes(timerMinutesInput.value);
    const delayMs = minutes * 60 * 1000;
    const endAt2 = Date.now() + delayMs;
    chrome.storage.local.set({ timerEndAt: endAt2 }, () => {
      chrome.storage.local.remove('timerPausedRemaining', () => {
        startCountdown(endAt2);
        sendStartTimer(delayMs);
      });
    });
  });
});

timerPauseBtn.addEventListener('click', () => {
  chrome.storage.local.get(['timerEndAt', 'timerPausedRemaining'], (data) => {
    const paused = (typeof data.timerPausedRemaining === 'number') ? data.timerPausedRemaining : 0;

    if (paused > 0) {
      const endAt = Date.now() + paused;
      chrome.storage.local.set({ timerEndAt: endAt }, () => {
        chrome.storage.local.remove('timerPausedRemaining', () => {
          startCountdown(endAt);
          sendStartTimer(paused);
        });
      });
      return;
    }

    if (typeof data.timerEndAt !== 'number') return;
    let remaining = data.timerEndAt - Date.now();
    if (remaining < 0) remaining = 0;

    chrome.storage.local.set({ timerPausedRemaining: remaining }, () => {
      chrome.storage.local.remove('timerEndAt', () => {
        stopCountdown();
        setPauseDisplay(remaining);
        sendStopTimer();
      });
    });
  });
});

timerStopBtn.addEventListener('click', () => {
  stopCountdown();
  setDisplay('Inactif');
  chrome.storage.local.remove(['timerEndAt', 'timerPausedRemaining'], () => {
    sendStopTimer();
  });
});

function loadAll() {
  chrome.storage.local.get(['notes', 'timerEndAt', 'timerPausedRemaining'], (data) => {
    if (chrome.runtime && chrome.runtime.lastError) {
      console.error('storage.get loadAll error', chrome.runtime.lastError);
    }

    notes = Array.isArray(data.notes) ? data.notes : [];
    renderNotes();

    if (typeof data.timerPausedRemaining === 'number' && data.timerPausedRemaining > 0) {
      setPauseDisplay(remaining);
      return;
    }

    if (typeof data.timerEndAt === 'number') {
      startCountdown(data.timerEndAt);
    } else {
      setDisplay('Inactif');
    }
  });
}

loadAll();
